=== Arrival Me ===
Contributors: WPoperation
Tags: two-columns, right-sidebar, custom-menu, custom-background, editor-style, translation-ready, full-width-template, flexible-header, sticky-post, theme-options, one-column, e-commerce, blog, photography, threaded-comments, custom-colors 
Requires at least: 4.7
Tested up to: 5.8.1
Stable tag: 1.0.7
Requires PHP: 5.6
License: GNU General Public License, version 3 (GPLv3)
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

Arrival Me is Child Theme Of Arrival.

Arrival Me is a WordPress Theme, 
Copyright (C) 2019, WPoperation
Arrival Me is distributed under the terms of the GNU GPL


Arrival WordPress Theme, 
Copyright 2019 WPoperation
Arrival is distributed under the terms of the GNU General Public License v3


== Description ==
Arrival Me is child theme of Arrival. This theme is extended & designed to meet the requirement for personal portfolio websites.


== Install Steps: ==

1. Activate the theme
2. Go to the Customize page
3. Setup theme options


== Resources ==

----------------------
Screenshot Images
----------------------
License: CC0
License Url : https://stocksnap.io/license

https://stocksnap.io/photo/B1ZGHDCDDO

https://pxhere.com/en/photo/775430


All other images are designed by WPoperation and licenced under CC0



== Changelog == 
please refer changelog.txt for changelogs